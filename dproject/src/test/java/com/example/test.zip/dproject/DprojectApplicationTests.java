package com.example.dproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
